Labdien!

Iesniedzam īsu aprakstu par mūsu projektu!

Par cik mums iet grūti ar programmēšanu II, bet cīnamies kā varam, tad komandā bijām pieci (palaidām garām par komandas dalībnieku skaitu, bet datoriumā nav info par cilvēku skaitu)

Nikola Smirnova, @nikoliiitee, loma komandā – kļūdu labojums

Adrians Druseiks, @mommylover69, loma komandā – back-end

Aksels Barausks @akselono, loma komandā – front-end

Kate Privalova @Kkaateee, loma komandā – savienojums ar json failu

Keita Privalova @keittaaa, loma komandā - dizains